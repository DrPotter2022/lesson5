class TopsController < ApplicationController
  layout 'index'

  def index
  end
end